
function redirectToLogin() {
    window.location.href = "login.html";
  }

function redirectToOrder(){
  window.location.href = "orderplaced.html";
}
function redirectToContact(){
  window.location.href = "send.html";
}

